import React, { useState, useEffect } from 'react'
import axios from 'axios';
import jwt_decode from "jwt-decode";
import { useNavigate } from 'react-router-dom';
import Navbar from "./Navbar";
 
const Dashboard = () => {
    const [name, setName] = useState('');
    const [token, setToken] = useState('');
    const [expire, setExpire] = useState('');
    const [msg, setMsg] = useState('');
    const [dataPosition, setDataPosition] = useState([]);

    const [page, setPage] = useState(1);
    const [description, setDescription] = useState('it');
    const [location, setLocation] = useState('');
    const [fulltime, setFulltime] = useState('');
    
    const navigation = useNavigate();
 
    useEffect(() => {
        refreshToken();
        Search();
    }, []);

    const refreshToken = async () => {
        try {
            const response = await axios.get('http://localhost:5000/token');
            setToken(response.data.accessToken);
            const decoded = jwt_decode(response.data.accessToken);
            setName(decoded.name);
            setExpire(decoded.exp);
        } catch (error) {
            if (error.response) {
                navigation("/");
            }
        }
    }
 
    const axiosJWT = axios.create();
 
    axiosJWT.interceptors.request.use(async (config) => {
        const currentDate = new Date();
        if (expire * 1000 < currentDate.getTime()) {
            const response = await axios.get('http://localhost:5000/token');
            config.headers.Authorization = `Bearer ${response.data.accessToken}`;
            setToken(response.data.accessToken);
            const decoded = jwt_decode(response.data.accessToken);
            setName(decoded.name);
            setExpire(decoded.exp);
        }
        return config;
    }, (error) => {
        return Promise.reject(error);
    });
    
    const Search = async () => {
        try {
            await axiosJWT.post('http://localhost:5000/recruitment', {
                page,
                description,
                location,
                fulltime,
            },{
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }).then(res => {
                if(res.data) setDataPosition(res.data)
            }).catch(err => {
                setMsg(JSON.stringify(err));
            });
        } catch (error) {
            if (error.response) {
                setMsg(error.response.data.msg);
            }
        }
    }
 
    return (
        <>
            <Navbar />
            <div className="container mt-5">
                <div className="columns">
                    <div className="column is-one-third">
                        <label className="label">Job Description</label>
                        <div className="controls">
                            <input type="text" className="input" placeholder='Filter by title, benefits, companies, expertise' value={description} onChange={(e) => setDescription(e.target.value)} />
                        </div>
                    </div>
                    <div className="column is-one-third">
                        <label className="label">Location</label>
                        <div className="controls">
                            <input type="text" className="input" placeholder='Filter by city, state, zip code or country' value={location} onChange={(e) => setLocation(e.target.value)} />
                        </div>
                    </div>
                    <div className="column is-one-fifth mt-5">
                        <div className="control">
                            <label className="checkbox">
                                <input type="checkbox" value={fulltime} onChange={(e) => setFulltime(e.target.checked) } ></input>
                                Full Time Only
                            </label>
                        </div>
                    </div>
                    <div className="column is-one-fifth mt-5">
                        <button className="button" onClick={Search}>Search</button>
                    </div>
                </div>
                <nav className="panel">
                    <p className="panel-heading">
                        Job List
                    </p>
                    {
                      dataPosition && dataPosition.map(function(o, i){
                        // panel-block
                        return <div key={i} className=""  style={{ padding:10 }}>
                            <div className="columns">
                                <div className="column is-10">
                                    {o.title}
                                </div>
                                <div style={{ textAlign:'right' }} className="column is-2">
                                    {o.location}
                                </div>
                            </div>
                        </div>
                      })
                    
                    }
                </nav>

            </div>
        </>
    )
}
 
export default Dashboard